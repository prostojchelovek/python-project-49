# Training project
project demonstration: [here](https://asciinema.org/a/rZiHS72ZGewT6UtL03NsQWmWz)

<a href="https://codeclimate.com/github/prostojchelovek/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/13f1b63f439da59c5253/maintainability" /></a>
### Hexlet tests and linter status:
[![Actions Status](https://github.com/prostojchelovek/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/prostojchelovek/python-project-49/actions)
